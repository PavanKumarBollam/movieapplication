import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-movie-component',
  templateUrl: './movie-component.component.html',
  styleUrls: ['./movie-component.component.css']
})
export class MovieComponentComponent implements OnInit {
  title="movie";
  readonly APP_URL = 'http://localhost:8010';
  myresponse: any =[];
  isTrue:boolean=false;
  myname:string;

  constructor(private http:HttpClient) { }


  call(){
    this.myname=this.myname;
    this.isTrue=true;
    this.http.get(this.APP_URL + '/catalog/' + this.myname).subscribe(
      data => {
        this.myresponse= data;
        console.log(this.myresponse)
      },
      error => {
        console.log('Error occured', error);
      }
    )
  }
  ngOnInit() {
  }

}
